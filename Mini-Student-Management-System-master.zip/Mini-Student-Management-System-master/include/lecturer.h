#ifndef LECTURER_QUYENJD_H
#define LECTURER_QUYENJD_H

namespace SMS
{
    void add_lecturer();
    void edit_lecturer();
    void delete_lecturer();
    void view_all_lecturers();
    void view_lecturers_of_course();
}

#endif // LECTURER_QUYENJD_H
